<?php 

/*
Plugin Name: Philosophy Social Widget
Plugin URI: https://github.com/saifur703/Meal-WP
Author: Saifur Rahman
Author URI: https://github.com/saifur703/
Description: Philosophy Social Widget Plugin.
Version: 1.0
License: GNU General Public License v2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html
Text Domain: philosophy
Domain Path: /languages
*/
function philosophy_social_widget_load_text_domain() {
    load_plugin_textdomain('philosophy-companion', false, dirname(__FILE__)."/languages");
}
add_action('plugin_loaded', 'philosophy_social_widget_load_text_domain');




include_once "social-icons-widget.php";